/*
=================================================================================
 Name        : pcd8544_rpi.c
 Version     : 3.0

##############################
 modify code by rei1984 @ Raspifans.com 
 add IP address. 20160316
 add CPU thermal degree 20160521
##############################

 Copyright (C) 2012 by Andre Wussow, 2012, desk@binerry.de

 Description :
     A simple PCD8544 LCD  for Raspberry Pi for displaying some system informations.
	 Makes use of WiringPI-library of Gordon Henderson (https://projects.drogon.net/raspberry-pi/wiringpi/)

	 Recommended connection (http://www.raspberrypi.org/archives/384):
	 LCD pins      Raspberry Pi
	 LCD1 - GND    P06  - GND
	 LCD2 - VCC    P01 - 3.3V
	 LCD3 - CLK    P11 - GPIO0
	 LCD4 - Din    P12 - GPIO1
	 LCD5 - D/C    P13 - GPIO2
	 LCD6 - CS     P15 - GPIO3
	 LCD7 - RST    P16 - GPIO4
	 LCD8 - LED    P01 - 3.3V 

================================================================================
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
================================================================================
 */
#include <wiringPi.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysinfo.h>
#include "PCD8544.h"

//ip address header files
#include <sys/types.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>

#include <sys/stat.h>
#include <fcntl.h>

#define CPU_USAGE_PATH "/proc/stat"
#define TEMP_PATH "/sys/class/thermal/thermal_zone0/temp"
#define MAX_SIZE 32

// pin setup
int _din = 1;
int _sclk = 0;
int _dc = 2;
int _rst = 4;
int _cs = 3;

// lcd contrast
//may be need modify to fit your screen!  normal: 30- 90 ,default is:45 !!!maybe modify this value!
int contrast = 60;

int main(void)
{
	struct ifaddrs *ifAddrStruct = NULL;
	void *tmpAddrPtr = NULL;

	getifaddrs(&ifAddrStruct);

	char buf_cpu[128];
	FILE *fp_CPUusage;
	char cpu[5];
	float usage;
	long int user, nice, sys, idle, iowait, irq, softirq;
	long int total_1, total_2, idle_1, idle_2;

	// print infos
	printf("Raspberry Pi PCD8544 sysinfo display\n");
	printf("========================================\n");

	// check wiringPi setup
	if (wiringPiSetup() == -1)
	{
		printf("wiringPi-Error\n");
		exit(1);
	}

	// init and clear lcd
	LCDInit(_sclk, _din, _dc, _cs, _rst, contrast);
	LCDclear();

	// show logo
	LCDshowLogo();

	delay(2000);


	for (;;)
	{
		// clear lcd
		LCDclear();
		sleep(0.1);

		// get system usage / info
		struct sysinfo sys_info;
		if (sysinfo(&sys_info) != 0)
		{
			printf("sysinfo-Error\n");
		}

		// uptime
		char uptimeInfo[MAX_SIZE];
		unsigned long uptime = sys_info.uptime / 60;
		sprintf(uptimeInfo, "Uptime %ld min.", uptime);

		// CPU info
		char CPUInfo[MAX_SIZE];
		//unsigned long avgCpuLoad = sys_info.loads[0] / 1000;
		//sprintf(CPUInfo, "CPU:%ld%%", avgCpuLoad);
		fp_CPUusage = fopen(CPU_USAGE_PATH, "r");
		if (fp_CPUusage == NULL)
		{
			printf("failed to open /proc/stat\n");
		}
		else
		{
			/*  CPU usage calculation method：usage = 100*(total-idle/total)
			* Get the total and idle by obtaining the data difference of /proc/stat 
			*/
			//Reading data for the first time
			fgets(buf_cpu, sizeof(buf_cpu), fp_CPUusage);
			sscanf(buf_cpu,"%s%d%d%d%d%d%d%d",cpu,&user,&nice,&sys,&idle,&iowait,&irq,&softirq);
			total_1 = user + nice + sys + idle + iowait + irq + softirq;
			idle_1 = idle;
			rewind(fp_CPUusage);

			//Delay and clear data
			sleep(1);
			memset(buf_cpu, 0, sizeof(buf_cpu));
			cpu[0] = '\0';
			user = nice = sys = idle = iowait = softirq = 0;

			//Reading data for the second time
			fgets(buf_cpu, sizeof(buf_cpu), fp_CPUusage);
			sscanf(buf_cpu,"%s%d%d%d%d%d%d%d",cpu,&user,&nice,&sys,&idle,&iowait,&irq,&softirq);
			total_2 = user + nice + sys + idle + iowait + irq + softirq;
			idle_2 = idle;

			usage = (float)(total_2-total_1-(idle_2-idle_1)) / (total_2-total_1)*100;
			sprintf(CPUInfo, "CPU:%.0f%%", usage);
			//printf("cpu:%.0f%%\n", usage);
			fclose(fp_CPUusage);
		}

		// ram info
		char ramInfo[MAX_SIZE];
		unsigned long totalRam = sys_info.freeram / 1024 / 1024;
		sprintf(ramInfo, "RAM %ld MB", totalRam);

		/*
		// IP address
		char IPInfo[MAX_SIZE];
		while (ifAddrStruct != NULL)
		{
			if (ifAddrStruct->ifa_addr->sa_family == AF_INET)
			{ // check it is IP4 is a valid IP4 Address

				tmpAddrPtr = &((struct sockaddr_in *)ifAddrStruct->ifa_addr)->sin_addr;
				char addressBuffer[INET_ADDRSTRLEN];
				inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);

				if (strcmp(ifAddrStruct->ifa_name, "eth0") == 0)
				{
					strcpy(IPInfo, addressBuffer);
					//sprintf(IPInfo, "IP:%s", addressBuffer);
					break;
					//printf("%s IP4 Address %s\n", ifAddrStruct->ifa_name, addressBuffer);
				}
			}
			ifAddrStruct = ifAddrStruct->ifa_next;
		}
		*/

		char CPUTemp[MAX_SIZE];
		{
			int i;
			for (i = 0; i < 15; i++)
			{
				CPUTemp[i] = 0;
			}
		}

		int fd;
		double temp = 0;
		char buf[MAX_SIZE];

		fd = open(TEMP_PATH, O_RDONLY);
		if (fd < 0)
		{
			printf("failed to open thermal_zone0/temp\n");
		}

		if (read(fd, buf, MAX_SIZE) < 0)
		{
			printf("failed to read temp\n");
		}

		temp = atoi(buf) / 1000.0;
		printf("temp: %.1f\n", temp);
		sprintf(CPUTemp, "CPUTemp:%.1f", temp);
		close(fd);

		LCDdrawstring(0, 1, "Raspberry Pi 4");
		
		LCDdrawline(0, 10, 83, 10, BLACK);
		
		LCDdrawstring(0, 12, uptimeInfo);
		
		LCDdrawstring(0, 21, CPUInfo);
		
		LCDdrawstring(0, 30, ramInfo);
		
		//LCDdrawstring(0, 39, IPInfo);  //ip
		LCDdrawstring(0, 39, CPUTemp);
		LCDdisplay();

		sleep(1);
	}
	return 0;
}
