#!/bin/sh
cd /home/pi/cpu_show_v3/cpu_show
./cpushow
